<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://summitbhc.com/
 * @since      0.0.1
 *
 * @package    Event_Client
 * @subpackage Event_Client/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
