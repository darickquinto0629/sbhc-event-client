<?php
class Create_Event_Route {
    public function __construct() {
        add_action( 'rest_api_init', array( $this, 'create_event_route' ) );
    }

    /**
     * Create an event from REST request.
     * Validates and sanitizes inputs, returns WP_REST_Response.
     */
    public function sbhc_create_event( WP_REST_Request $request ) {
        $params = $request->get_params();

        $event_title = isset( $params['event_title'] ) ? sanitize_text_field( $params['event_title'] ) : '';
        if ( empty( $event_title ) ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => 'Missing event_title' ), 400 );
        }

        $event_content = isset( $params['event_content'] ) ? wp_kses_post( $params['event_content'] ) : '';

        $meta = isset( $params['meta_input'] ) && is_array( $params['meta_input'] ) ? $params['meta_input'] : array();

        // Build sanitized meta_input for wp_insert_post
        $meta_input = array();
        $map_text = array(
            'event_time_zone' => '_event_timezone',
            'event_start_time' => '_event_start_time',
            'event_end_time' => '_event_end_time',
            'event_start' => '_event_start',
            'event_end' => '_event_end',
            'event_start_date' => '_event_start_date',
            'event_end_date' => '_event_end_date',
            'event_active_status' => '_event_active_status',
            'event_start_local' => '_event_start_local',
            'event_end_local' => '_event_end_local',
        );

        foreach ( $map_text as $src => $dst ) {
            if ( isset( $meta[ $src ] ) ) {
                $meta_input[ $dst ] = sanitize_text_field( $meta[ $src ] );
            }
        }

        $author = get_current_user_id() ? get_current_user_id() : 1;

        $post_args = array(
            'post_type'    => 'event',
            'post_title'   => $event_title,
            'post_content' => $event_content,
            'post_status'  => 'publish',
            'post_author'  => $author,
            'meta_input'   => $meta_input,
        );

        $post_id = wp_insert_post( $post_args, true );
        if ( is_wp_error( $post_id ) ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => $post_id->get_error_message() ), 500 );
        }

        // Set featured image if provided
        if ( isset( $params['featured_media'] ) && is_numeric( $params['featured_media'] ) ) {
            set_post_thumbnail( $post_id, intval( $params['featured_media'] ) );
        }

        // ACF updates (only if ACF present)
        if ( function_exists( 'update_field' ) ) {
            $acf_map = array(
                'presenter' => 'presenter',
                'ticket_price' => 'ticket_price',
                'event_location' => 'location',
                'event_type' => 'event_location_type',
                'summary' => 'summary',
                'short_summary' => 'short_summary',
            );
            foreach ( $acf_map as $req_key => $field_key ) {
                if ( isset( $params[ $req_key ] ) ) {
                    update_field( $field_key, sanitize_text_field( $params[ $req_key ] ), $post_id );
                }
            }

            // Contact info
            $contact_map = array( 'contact_name' => 'name', 'contact_number' => 'number', 'contact_address' => 'address', 'registration_link' => 'registration_link' );
            foreach ( $contact_map as $req_key => $field_key ) {
                if ( isset( $params[ $req_key ] ) ) {
                    update_field( $field_key, sanitize_text_field( $params[ $req_key ] ), $post_id );
                }
            }

            if ( isset( $params['objectives'] ) && is_array( $params['objectives'] ) ) {
                foreach ( $params['objectives'] as $row ) {
                    if ( ! empty( $row ) ) {
                        add_row( 'learning_objectives', array( 'objectives' => sanitize_text_field( $row ) ), $post_id );
                    }
                }
            }
        }

        // Mirror into em_events table if present
        global $wpdb;
        $et = $wpdb->prefix . 'em_events';
        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $et ) ) === $et ) {
            $d = array(
                'event_name' => $event_title,
                'event_status' => 1,
                'event_slug' => sanitize_title( $event_title ),
                'post_id' => $post_id,
                'event_start_date' => isset( $meta_input['_event_start_date'] ) ? $meta_input['_event_start_date'] : '',
                'event_end_date' => isset( $meta_input['_event_end_date'] ) ? $meta_input['_event_end_date'] : '',
                'event_start' => isset( $meta_input['_event_start'] ) ? $meta_input['_event_start'] : '',
                'event_end' => isset( $meta_input['_event_end'] ) ? $meta_input['_event_end'] : '',
                'event_timezone' => isset( $meta_input['_event_timezone'] ) ? $meta_input['_event_timezone'] : '',
                'event_active_status' => isset( $meta_input['_event_active_status'] ) ? $meta_input['_event_active_status'] : 0,
                'event_owner' => isset( $meta['event_owner'] ) ? sanitize_text_field( $meta['event_owner'] ) : '',
            );
            $formats = array_fill( 0, count( $d ), '%s' );
            $formats[1] = '%d'; // event_status
            $formats[3] = '%d'; // post_id
            $wpdb->insert( $et, $d, $formats );
        }

        return new WP_REST_Response( array( 'success' => true, 'post_id' => $post_id ), 201 );

    }
    
    public function media_upload( WP_REST_Request $request ) {
        if ( ! current_user_can( 'upload_files' ) ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => 'Forbidden' ), 403 );
        }

        $files = $request->get_file_params();
        if ( empty( $files ) ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => 'No file uploaded' ), 400 );
        }

        // Prefer standard 'file' key, otherwise use the first uploaded file.
        $file_key = isset( $files['file'] ) ? 'file' : array_key_first( $files );

        return $this->uploadFile( $file_key );
    }

    public function uploadFile( $file_key = 'async-upload' ) {
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        //upload only images and files with the following extensions
        $file_extension_type = array('jpg', 'jpeg', 'jpe', 'gif', 'png', 'bmp', 'tiff', 'tif', 'ico', 'zip', 'pdf', 'docx');
        if ( empty( $_FILES ) || ! isset( $_FILES[ $file_key ] ) ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => 'No file in request' ), 400 );
        }

        $filename = $_FILES[ $file_key ]['name'];
        $file_extension = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
        if ( ! in_array( $file_extension, $file_extension_type, true ) ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => 'Invalid file type', 'filename' => esc_html( $filename ) ), 400 );
        }

        $attachment_id = media_handle_upload( $file_key, 0 );

        if ( is_wp_error( $attachment_id ) ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => $attachment_id->get_error_message(), 'filename' => esc_html( $filename ) ), 500 );
        }

        if (isset($post_data['context']) && isset($post_data['theme'])) {
            if ('custom-background' === $post_data['context']) {
                update_post_meta($attachment_id, '_wp_attachment_is_custom_background', $post_data['theme']);
            }

            if ('custom-header' === $post_data['context']) {
                update_post_meta($attachment_id, '_wp_attachment_is_custom_header', $post_data['theme']);
            }
        }

        $attachment = wp_prepare_attachment_for_js( $attachment_id );
        if ( ! $attachment ) {
            return new WP_REST_Response( array( 'success' => false, 'message' => 'Attachment processing failed', 'filename' => esc_html( $filename ) ), 500 );
        }

        return new WP_REST_Response( array( 'success' => true, 'attachment_id' => $attachment['id'], 'attachment' => $attachment ), 201 );
            
    }	
    
    public function create_event_route() {
        register_rest_route( 'sbhc/v2', 'postevent', array(
            'methods' => WP_REST_Server::CREATABLE, // POST
            'callback' => array( $this, 'sbhc_create_event' ),
            'permission_callback' => array( $this, 'post_events_permission' ),
        ) );

        register_rest_route( 'sbhc/v2', 'media_upload', array(
            'methods' => WP_REST_Server::CREATABLE, // POST
            'callback' => array( $this, 'media_upload' ),
            'permission_callback' => array( $this, 'post_media_permission' ),
        ) );
    }
	
	public function post_events_permission() {
		if( current_user_can( 'edit_posts' ) ) {
			return true;
		}
		return false;
	}	

    public function post_media_permission() {
        if ( current_user_can( 'upload_files' ) ) {
            return true;
        }
        return false;
    }
       
}

new Create_Event_Route();

?>